use lib qw(./blib/lib ./blib/arch);
use strict;
use warnings;
use KyotoCabinet;
use Time::HiRes qw(gettimeofday);

sub memoryusage {
    my $rss = -1;
    open(my $fh, "/proc/self/status");
    while (defined(my $line = <$fh>)) {
        chomp($line);
        if($line =~ /^VmRSS:/){
            $line =~ s/.*:\s*(\d+).*/$1/;
            return int($line) / 1024.0;
        }
    }
    return $rss;
}

my $musage = memoryusage();
my $rnum = 1000000;
if(scalar(@ARGV) > 0){
    $rnum = int($ARGV[0]);
}

my %hash;
if(scalar(@ARGV) > 1){
    tie(%hash, "KyotoCabinet::DB", $ARGV[1]) || die("tie failed");
}

my $stime = gettimeofday();
for(my $i = 0; $i < $rnum; $i++){
    my $key = sprintf("%08d", $i);
    my $value = sprintf("%08d", $i);
    $hash{$key} = $value;
}
my $etime = gettimeofday();

printf("Time: %.3f sec.\n", $etime - $stime);
printf("Usage: %.3f MB\n", memoryusage() - $musage);

#! /usr/bin/perl

use strict;
use warnings;
use Test::More qw(no_plan);

my @confs = (
    [ ":", 10000 ],
    [ "*", 10000 ],
    [ "%", 10000 ],
    [ "casket.kch", 10000 ],
    [ "casket.kct", 10000 ],
    [ "casket.kcd", 1000 ],
    [ "casket.kcf", 10000 ],
    );
my @formats = (
    "kctest.pl order '%s' '%d'",
    "kctest.pl order -rnd '%s' '%d'",
    "kctest.pl order -etc '%s' '%d'",
    "kctest.pl order -rnd -etc '%s' '%d'",
    "kctest.pl wicked '%s' '%d'",
    "kctest.pl wicked -it 4 '%s' '%d'",
    "kctest.pl misc '%s'",
    );

system("rm -rf casket*");

foreach my $conf (@confs) {
    my $path = $conf->[0];
    my $rnum = $conf->[1];
    foreach my $format (@formats) {
        my $cmd = sprintf($format, $path, $rnum);
        my $rv = system("$^X $cmd >/dev/null");
        ok($rv == 0, $cmd);
    }
}

system("rm -rf casket*")
